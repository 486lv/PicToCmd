# PicToCmd

PicToCmd 是一个将图像转换为 ASCII 艺术并保存为命令字符数组的 Python 库。

## 安装

```bash
pip install PicToCmd
